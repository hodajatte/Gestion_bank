package view;

import model.Compte;
import service.BanqueService;

import java.util.Scanner;

public class Main {

    public static int Menu(){
        Scanner sc=new Scanner(System.in);
        System.out.println("-----------WELOCME TO THE BANK OF JAVA-----------");
        System.out.println("1-----------Create a new account------------------");
        System.out.println("2-----------modify an account--------------------");
        System.out.println("3-----------delete an account--------------------");
        System.out.println("4-----------consult an account-------------------");
        System.out.println("5-----------create a new client------------------");
        System.out.println("6-----------modify client------------------------");
        System.out.println("7-----------attach compte to client--------------");
        System.out.println("8-----------delete client------------------------");
        System.out.println("9-----------consult client-----------------------");
        System.out.println("10----------lister client------------------------");
        System.out.println("11----------lister compte------------------------");
        System.out.println("12----------effectuer un virement----------------");
        System.out.println("13----------Exit---------------------------------");
        System.out.println("------------------------------------------------");
        System.out.println("Enter your choice");
        int x =sc.nextInt();
        return x;
    }

    public static void main(String[] args) {


        BanqueService banqueService = new BanqueService("CIH", "CIH@CIH.ma", 100, 100);
        Scanner clavier = new Scanner(System.in);
        boolean fin = false;

        while (!fin) {

            switch (Menu()) {
                case 1:
                    banqueService.creerEtAjouterCompte(clavier);
                    break;
                case 2:
                    banqueService.modifierCompte(clavier);
                    break;
                case 3:
                    banqueService.supprimerCompte(clavier);
                    break;
                case 4:
                    banqueService.consulterDetailCompte(clavier);
                    break;
                case 5:
                    banqueService.creerEtAjouterCLient(clavier);
                    break;
                case 6:
                    banqueService.modifierClient(clavier);
                    break;
                case 7:
                    System.out.print("id client : ");
                    int idClient = clavier.nextInt();
                    System.out.print("id compte : ");
                    int idCompte = clavier.nextInt();
                    banqueService.lierCompteAuClient(idClient, idCompte);
                    break;
                case 8:
                    banqueService.supprimerClient(clavier);
                    break;
                case 9:
                    banqueService.consulterDetailClient(clavier);
                    break;
                case 10:
                    banqueService.listerClientsDeLaBanque(clavier);
                    break;
                case 11:
                    banqueService.listerComptesDeLaBanque(clavier);
                    break;
                case 12:
                    System.out.println("compte a debiter : ");
                    Compte src = banqueService.chercherCompte(clavier);
                    System.out.println("compte a crediter : ");
                    Compte des = banqueService.chercherCompte(clavier);
                    System.out.print("montant : ");
                    double montant = clavier.nextDouble();
                    banqueService.virement(montant, src, des);
                    break;
                case 13:
                    fin = true;
                    break;
                default:

            }

            System.out.println("--------------------------------------------------");
            System.out.println("--------------------------------------------------");
            System.out.println("--------------------------------------------------");
            System.out.println("--------------------------------------------------");
            System.out.println("--------------------------------------------------");


        }


        System.out.println("Fin de l'application");


    }

}


