package model;

import java.util.Date;

public class Compte extends AbstractModel{

    private double solde;
    private Date createdAt;
    private Client client;



    public double getSolde() {
        return solde;
    }

    public void setSolde(double solde) {
        if(solde <= 0)
            return;
        this.solde = solde;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
