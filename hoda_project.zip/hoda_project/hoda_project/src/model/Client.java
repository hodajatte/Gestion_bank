package model;

import java.util.ArrayList;
import java.util.List;

public class Client extends AbstractModel{

    private String nom;
    private String prenom;
    private String email;
    private List<Compte> comptes;

    public Client() {
        super();
        this.comptes = new ArrayList<>();
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Compte> getComptes() {
        return comptes;
    }

    public void setComptes(List<Compte> comptes) {
        this.comptes = comptes;
    }

    public double calculerSolde() {
        double soldeTotal = 0;
        for(Compte c: comptes) {
            soldeTotal += c.getSolde();
        }
        return soldeTotal;
    }
}
