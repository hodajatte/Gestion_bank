package model;

public abstract class AbstractModel {

    private static int idSeq = 0;
    private int id;

    public AbstractModel() {
        this.id = ++idSeq;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {
        return ((AbstractModel)obj).id == this.id;
    }
}
