package model;

import java.util.ArrayList;
import java.util.List;

public class Banque extends AbstractModel{

    private String nomAgence;
    private String emailAgence;
    private int maxComptes;
    private int maxClients;
    private List<Client> clients;
    private List<Compte> comptes;

    public Banque(String nomAgence, String emailAgence, int maxComptes, int maxClients) {
        super();
        this.maxComptes = maxComptes;
        this.maxClients = maxClients;
        this.clients = new ArrayList<>();
        this.comptes = new ArrayList<>();
    }

    public String getNomAgence() {
        return nomAgence;
    }

    public void setNomAgence(String nomAgence) {
        this.nomAgence = nomAgence;
    }

    public String getEmailAgence() {
        return emailAgence;
    }

    public void setEmailAgence(String emailAgence) {
        this.emailAgence = emailAgence;
    }

    public int getMaxComptes() {
        return maxComptes;
    }

    public void setMaxComptes(int maxComptes) {
        this.maxComptes = maxComptes;
    }

    public int getMaxClients() {
        return maxClients;
    }

    public void setMaxClients(int maxClients) {
        this.maxClients = maxClients;
    }

    public List<Client> getClients() {
        return clients;
    }

    public void setClients(List<Client> clients) {
        this.clients = clients;
    }

    public List<Compte> getComptes() {
        return comptes;
    }

    public void setComptes(List<Compte> comptes) {
        this.comptes = comptes;
    }

    public Client getClientById(int idClient) {
        for(Client c : this.clients) {
            if(c.getId() == idClient)
                return c;
        }

        return null;
    }

    public Compte getCompteById(int idCompte) {
        for(Compte c : this.comptes) {
            if(c.getId() == idCompte)
                return c;
        }

        return null;
    }

}
