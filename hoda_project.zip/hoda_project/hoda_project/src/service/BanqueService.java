package service;

import model.Banque;
import model.Client;
import model.Compte;

import java.text.SimpleDateFormat;
import java.util.*;

public class BanqueService {

    public Banque banque;



    public BanqueService(String nomAgence, String emailAgence, int maxComptes, int maxCLients) {
        banque = new Banque(nomAgence, emailAgence, maxComptes, maxCLients);
    }


    public boolean verser(double montant, Compte c) {
        c.setSolde(c.getSolde() + montant);
        return true;
    }

    public boolean retirer(double montant, Compte c) {
        if(montant > c.getSolde())
            return false;
        c.setSolde(c.getSolde() - montant);
        return true;
    }

    public boolean virement(double montant, Compte src, Compte des) {

        if(!retirer(montant, src))
            return false;
        if(!verser(montant, des))
            return false;
        return true;
    }

    public boolean creerEtAjouterCompte(Scanner clavier) {

        Compte c = new Compte();
        c.setCreatedAt(new Date());
        System.out.print("solde : ");
        c.setSolde(clavier.nextDouble());
        banque.getComptes().add(c);
        return true;
    }
    public boolean creerEtAjouterCLient(Scanner clavier) {

        Client c = new Client();

        System.out.print("nom : ");
        c.setNom(clavier.next());
        System.out.print("prenom : ");
        c.setPrenom(clavier.next());
        System.out.print("email : ");
        c.setEmail(clavier.next());
        banque.getClients().add(c);

        return true;
    }

    public boolean lierCompteAuClient(int idClient, int idCompte) {
        Client client = banque.getClientById(idClient);
        if(client == null)
            return false;
        Compte compte = banque.getCompteById(idCompte);
        if(compte == null)
            return false;
        compte.setClient(client);
        client.getComptes().add(compte);
        return true;
    }

    public Compte chercherCompte(Scanner clavier) {

        System.out.print("id du compte : ");
        int id = clavier.nextInt();
        Compte c = banque.getCompteById(id);
        return c;
    }

    public Client chercherClient(Scanner clavier) {
        System.out.print("id du client : ");
        int id = clavier.nextInt();
        Client c = banque.getClientById(id);
        return c;
    }

    public void consulterDetailCompte(Scanner clavier) {
        Compte c = chercherCompte(clavier);
        if(c == null)
            return;
        System.out.println("id : " + c.getId());
        System.out.println("solde : " + c.getSolde());
        System.out.println("date creation : " + new SimpleDateFormat("dd-mm-yyyy").format(c.getCreatedAt()));
    }

    public void consulterDetailClient(Scanner clavier) {
        Client c = chercherClient(clavier);
        if(c == null)
            return;
        System.out.println("id : " + c.getId());
        System.out.println("nom : " + c.getNom());
        System.out.println("prenom : " + c.getPrenom());
        System.out.println("email : " + c.getEmail());
    }


    public boolean modifierCompte(Scanner clavier) {
        Compte c = chercherCompte(clavier);
        if(c==null)
            return false;
        System.out.print("nouveau solde : ");
        c.setSolde(clavier.nextDouble());
        return true;
    }

    public boolean modifierClient(Scanner clavier) {
        Client c = chercherClient(clavier);
        if(c==null)
            return false;
        System.out.print("nouveau nom : ");
        c.setNom(clavier.next());
        System.out.print("nouveau prenom : ");
        c.setPrenom(clavier.next());
        System.out.print("nouveau email : ");
        c.setEmail(clavier.next());
        return true;
    }

    public boolean supprimerCompte(Scanner clavier) {
        Compte c = chercherCompte(clavier);
        if(c==null)
            return false;
        return banque.getComptes().remove(c);
    }

    public boolean supprimerClient(Scanner clavier) {
        Client c = chercherClient(clavier);
        if(c==null)
            return false;
        return banque.getClients().remove(c);
    }

    public void consulterInformationsBanque(Scanner clavier) {
        System.out.println("nom agence : " + banque.getNomAgence());
        System.out.println("email agence : " + banque.getEmailAgence());
        System.out.println("nombre des clients : " + banque.getClients().size());
        System.out.println("nombre des comptes : " + banque.getComptes().size());
    }

    public void listerComptesDeLaBanque(Scanner clavier) {

        for(Compte c : banque.getComptes()) {
            System.out.println("id : " + c.getId());
            System.out.println("solde : " + c.getSolde());
            System.out.println("date creation : " + new SimpleDateFormat("dd-mm-yyyy").format(c.getCreatedAt()));
            System.out.println("----------------------------------------");
        }

    }
    public void listerClientsDeLaBanque(Scanner clavier) {

        System.out.print("voullez vous triez par [1 = nom et prenom] ou [2 = solde] ?");
        int choix = clavier.nextInt();
        List<Client> clients = new ArrayList<>();
        switch (choix) {
            case 1:
                clients = trierCLientsParNom(clavier);
                break;
            case 2:
                System.out.println("ordre de trie [1 = croissant] ou [autre = decroissant]");
                int choix2 = clavier.nextInt();
                clients = trierCLientsParSolde(clavier);
                if(choix2 != 1)
                    Collections.reverse(clients);
                break;
            default:
                System.out.println("choix invalide !");
        }

        for(Client c : clients) {
            System.out.println("id : " + c.getId());
            System.out.println("nom : " + c.getNom());
            System.out.println("prenom : " + c.getPrenom());
            System.out.println("email : " + c.getEmail());
            System.out.println("solde total : " + c.calculerSolde());
            System.out.println("----------------------------------------");
        }

    }


    public List<Client> trierCLientsParDate(Scanner clavier) {

        return new ArrayList<>();
    }

    public List<Client> trierCLientsParSolde(Scanner clavier) {

        List<Client> clientsCloned = new ArrayList<>();
        clientsCloned.addAll(banque.getClients());
        Collections.sort(clientsCloned, new Comparator<Client>() {
            @Override
            public int compare(Client client, Client t1) {
                return (int) (client.calculerSolde() - t1.calculerSolde());
            }
        });

        return clientsCloned;
    }

    public List<Client> trierCLientsParNom(Scanner clavier) {
        List<Client> clientsCloned = new ArrayList<>();
        clientsCloned.addAll(banque.getClients());
        Collections.sort(clientsCloned, new Comparator<Client>() {
            @Override
            public int compare(Client client, Client t1) {
                return ( client.getNom() + client.getPrenom() ).compareTo( t1.getNom() + t1.getPrenom() );
            }
        });

        return clientsCloned;
    }



}
